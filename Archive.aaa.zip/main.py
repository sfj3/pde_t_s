import yfinance as yf
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def get_stock_data(symbol, period="1y"):
    stock = yf.Ticker(symbol)
    return stock.history(period=period, interval="1d")

def calculate_derivatives(data, order=3):
    derivatives = [data]
    for i in range(1, order + 1):
        derivatives.append(np.diff(derivatives[-1], n=1, prepend=np.nan))
    return np.array(derivatives)

def estimate_price_change(prices, derivatives):
    price = prices[-1]
    price_prime = derivatives[1][-1]
    price_double_prime = derivatives[2][-1]
    
    estimated_change = (price_double_prime + price) / price_prime if price_prime != 0 else 0
    return estimated_change

def calculate_option_value(option_type, current_price, strike_price, days_to_expiry):
    time_factor = days_to_expiry / 365
    if option_type == 'call':
        return max(0, current_price - strike_price) + (current_price * 0.1 * np.sqrt(time_factor))
    elif option_type == 'put':
        return max(0, strike_price - current_price) + (current_price * 0.1 * np.sqrt(time_factor))

def display_portfolio(portfolio, current_price):
    print("\nCurrent Portfolio:")
    print(f"Long Stocks: {portfolio['long_stocks']} shares")
    print(f"Short Stocks: {portfolio['short_stocks']} shares")
    if portfolio['options']:
        print("Options:")
        for idx, option in enumerate(portfolio['options']):
            current_value = calculate_option_value(option['type'], current_price, option['strike_price'], option['days_to_expiry'])
            print(f"{idx+1}. {option['type'].upper()} option - Strike: ${option['strike_price']:.2f}, "
                  f"Days to expiry: {option['days_to_expiry']}, Current Value: ${current_value:.2f}, "
                  f"Contracts: {option['num_contracts']}")

def execute_trade(action, portfolio, account_balance, current_price, daily_investment):
    if action == 'buy_stock':
        max_shares = int(daily_investment / current_price)
        num_shares = int(input(f"Enter number of shares to buy (max {max_shares}): "))
        if 0 < num_shares <= max_shares:
            cost = num_shares * current_price
            account_balance -= cost
            portfolio['long_stocks'] += num_shares
            print(f"Bought {num_shares} shares for ${cost:.2f}")
        else:
            print("Invalid number of shares.")
    
    elif action == 'sell_stock':
        max_shares = portfolio['long_stocks']
        if max_shares > 0:
            num_shares = int(input(f"Enter number of shares to sell (max {max_shares}): "))
            if 0 < num_shares <= max_shares:
                sale_value = num_shares * current_price
                account_balance += sale_value
                portfolio['long_stocks'] -= num_shares
                print(f"Sold {num_shares} shares for ${sale_value:.2f}")
            else:
                print("Invalid number of shares.")
        else:
            print("No long stocks in portfolio to sell.")
    
    elif action == 'short_stock':
        max_shares = int(daily_investment / current_price)
        num_shares = int(input(f"Enter number of shares to short (max {max_shares}): "))
        if 0 < num_shares <= max_shares:
            sale_value = num_shares * current_price
            account_balance += sale_value
            portfolio['short_stocks'] += num_shares
            print(f"Shorted {num_shares} shares for ${sale_value:.2f}")
        else:
            print("Invalid number of shares.")
    
    elif action == 'cover_short':
        max_shares = portfolio['short_stocks']
        if max_shares > 0:
            num_shares = int(input(f"Enter number of shares to cover (max {max_shares}): "))
            if 0 < num_shares <= max_shares:
                cost = num_shares * current_price
                account_balance -= cost
                portfolio['short_stocks'] -= num_shares
                print(f"Covered {num_shares} shorted shares for ${cost:.2f}")
            else:
                print("Invalid number of shares.")
        else:
            print("No short stocks in portfolio to cover.")
    
    elif action == 'buy_option':
        option_type = input("Enter option type (call/put): ").lower()
        if option_type in ['call', 'put']:
            strike_price = current_price
            days_to_expiry = 30
            option_price = calculate_option_value(option_type, current_price, strike_price, days_to_expiry)
            max_contracts = daily_investment // (option_price * 100)
            num_contracts = int(input(f"Enter number of contracts to buy (max {max_contracts}): "))
            if 0 < num_contracts <= max_contracts:
                cost = num_contracts * option_price * 100
                account_balance -= cost
                portfolio['options'].append({
                    'type': option_type,
                    'strike_price': strike_price,
                    'days_to_expiry': days_to_expiry,
                    'num_contracts': num_contracts,
                    'cost': cost
                })
                print(f"Bought {num_contracts} {option_type.upper()} option contracts for ${cost:.2f}")
            else:
                print("Invalid number of contracts.")
        else:
            print("Invalid option type.")
    
    elif action == 'sell_option':
        if portfolio['options']:
            option_index = int(input("Enter the number of the option to sell (0 to cancel): ")) - 1
            if 0 <= option_index < len(portfolio['options']):
                option = portfolio['options'][option_index]
                max_contracts = option['num_contracts']
                num_to_sell = int(input(f"Enter number of contracts to sell (max {max_contracts}): "))
                if 0 < num_to_sell <= max_contracts:
                    current_value = calculate_option_value(option['type'], current_price, option['strike_price'], option['days_to_expiry'])
                    sale_value = current_value * num_to_sell * 100
                    account_balance += sale_value
                    profit = sale_value - (option['cost'] * num_to_sell / option['num_contracts'])
                    print(f"Sold {num_to_sell} {option['type'].upper()} option contracts for ${sale_value:.2f}. Profit: ${profit:.2f}")
                    option['num_contracts'] -= num_to_sell
                    option['cost'] -= option['cost'] * num_to_sell / max_contracts
                    if option['num_contracts'] == 0:
                        portfolio['options'].pop(option_index)
                else:
                    print("Invalid number of contracts.")
            else:
                print("Invalid option number.")
        else:
            print("No options in portfolio to sell.")
    
    return portfolio, account_balance

def main():
    symbol = input("Enter stock symbol (e.g., AAPL): ")
    stock_data = get_stock_data(symbol)
    
    print(f"Starting the stock broker game for {symbol} with {len(stock_data)} days of data")
    
    account_balance = 1000000
    daily_investment = 10000
    portfolio = {'options': [], 'long_stocks': 0, 'short_stocks': 0}
    
    for i in range(30, len(stock_data)):
        window = stock_data.iloc[i-30:i+1]
        prices = window['Close'].values
        derivatives = calculate_derivatives(prices)
        estimated_change = estimate_price_change(prices, derivatives)
        current_price = prices[-1]
        
        print(f"\nDay {i-29} - {window.index[-1].date()}")
        print(f"Current Price: ${current_price:.2f}")
        print(f"Estimated Change: ${estimated_change:.2f}")
        print(f"Current Account Balance: ${account_balance:.2f}")
        
        display_portfolio(portfolio, current_price)
        
        while True:
            action = input("\nEnter action (buy_stock/sell_stock/short_stock/cover_short/buy_option/sell_option/hold/next_day): ").lower()
            if action == 'next_day':
                break
            elif action in ['buy_stock', 'sell_stock', 'short_stock', 'cover_short', 'buy_option', 'sell_option']:
                portfolio, account_balance = execute_trade(action, portfolio, account_balance, current_price, daily_investment)
            elif action == 'hold':
                print("Holding position for now.")
            else:
                print("Invalid action. Please try again.")
        
        # Update days to expiry for all options in portfolio
        for option in portfolio['options']:
            option['days_to_expiry'] -= 1
            if option['days_to_expiry'] == 0:
                current_value = calculate_option_value(option['type'], current_price, option['strike_price'], 0)
                account_balance += current_value * option['num_contracts'] * 100
                print(f"{option['type'].upper()} option expired. Value added to account: ${current_value * option['num_contracts'] * 100:.2f}")
        
        # Remove expired options
        portfolio['options'] = [option for option in portfolio['options'] if option['days_to_expiry'] > 0]
    
    # Calculate final stock value
    final_long_value = portfolio['long_stocks'] * current_price
    account_balance += final_long_value
    print(f"\nSold remaining {portfolio['long_stocks']} long shares for ${final_long_value:.2f}")
    
    final_short_value = portfolio['short_stocks'] * current_price
    account_balance -= final_short_value
    print(f"\nCovered remaining {portfolio['short_stocks']} short shares for ${final_short_value:.2f}")
    
    print("\nGame Over!")
    print(f"Final Account Balance: ${account_balance:.2f}")
    total_profit = account_balance - 1000000
    print(f"Total Profit: ${total_profit:.2f}")

if __name__ == "__main__":
    main()