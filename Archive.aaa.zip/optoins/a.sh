#!/bin/bash

# Function to get mouse coordinates
get_mouse_coordinates() {
    cliclick p | tr ':' ','
}

# Main loop to continuously stream mouse coordinates
while true; do
    coordinates=$(get_mouse_coordinates)
    echo "Mouse coordinates: $coordinates"
    sleep 2  # Adjust this value to change the update frequency
done