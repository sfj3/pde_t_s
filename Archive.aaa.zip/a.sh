#!/bin/bash

# Function to get mouse coordinates with high precision
get_mouse_coordinates() {
    ./get_mouse_pos
}

# Main loop to continuously stream mouse coordinates
while true; do
    coordinates=$(get_mouse_coordinates)
    echo "Mouse coordinates: $coordinates"
    sleep 0.1  # Adjust this value to change the update frequency
done