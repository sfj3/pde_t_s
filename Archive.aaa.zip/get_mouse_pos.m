#import <Foundation/Foundation.h>
#import <ApplicationServices/ApplicationServices.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        CGEventRef event = CGEventCreate(NULL);
        CGPoint cursor = CGEventGetLocation(event);
        CFRelease(event);
        printf("%.6f,%.6f\n", cursor.x, cursor.y);
    }
    return 0;
}